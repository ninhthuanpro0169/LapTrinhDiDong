package com.example.travelgood.ultil;

public class Server {
    public static String localhost = "172.19.200.59";
    public static String DuongdanLoaidl = "http://" + localhost + ":8080/server/getloaidl.php";
    public static String Duongdandulichhot = "http://" + localhost + ":8080/server/getdulichhot.php";
    public static String Duongdandulichsinhthai = "http://" + localhost + ":8080/server/getdulich.php?page=";
    public static String Duongdandulichkhampha = "http://" + localhost + ":8080/server/getdulich.php?page=";
    public static String Duongdandulichthamquan = "http://" + localhost + ":8080/server/getdulich.php?page=";

}
